var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var helmet = require('helmet');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var accountRouter = require('./routes/account');
var template = require('art-template');
var createError = require('http-errors');

var app = express();

// 设置模板渲染根目录为views
app.set('views', path.join(__dirname, 'views'));
// 模板引擎渲染文件格式为.html后缀的文件，即views/*/*.html
app.set('view engine', 'html');
// 设置模板引擎为express-art-template
app.engine('html', require('express-art-template'));
app.set('view options', {
    debug: process.env.NODE_ENV !== 'production'
});

// 模版配置， 将 {{}} 替换掉<\\\?  \\\?> 避免跟 vue 的{{}} 冲突，语法使用由{{lala}}变成<?title?>
var rule = template.defaults.rules[1];
rule.test = new RegExp(rule.test.source.replace('{{', '<\\\?').replace('}}', '\\\?>'));

app.use(
    helmet({
        dnsPrefetchControl: { allow: true }
    })
);
// 载入中间件
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
// 设置静态资源根目录路径，比如url：/static/xxx会默认访问public/xxx的内容
app.use('/static', express.static(path.join(__dirname, 'public')));
// vue-cli打包模块静态资源路径配置
app.use('/js', express.static(path.join(__dirname, 'views/manageVue/js')));
app.use('/css', express.static(path.join(__dirname, 'views/manageVue/css')));
app.use('/img', express.static(path.join(__dirname, 'views/manageVue/img')));
// 路由设置(views/template存放的是art模板html文件，views/manage存放的是vue项目html文件)
app.use('/index', indexRouter);
app.use('/account', accountRouter);
// /manage/*路由重定向到vue模块文件，vue模块放在views/manage里面
app.use('/manage/*', function(req, res, next) {
    res.render('./manage/vueIndex.html');
});
// /manage/*路由重定向到vue-cli打包模块文件，vue-cli打包模块放在views/manageVue里面
app.use('/manageVue/*', function(req, res, next) {
    res.render('./manageVue/index.html');
});

// catch 404 and forward to error handler
// app.use(function(req, res, next) {
//     next(createError(404));
// });
// 路由不存在默认重定向到首页
app.get('*', function(req, res) {
    res.redirect('/index');
});

// error handler
app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
    // render the error page
    console.log(err);
    res.status(err.status || 500);
    res.render('error.art', { error: err });
});

module.exports = app;