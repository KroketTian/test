var express = require('express');
var router = express.Router();
var mysqlPool = require('../config/mysql');
var UserSQL = require('../config/api/userSQL');

router.get('/', function(req, res, next) {
    // mysqlPool.getConnection(function(err, connection) {
    //     connection.query(UserSQL.queryAll + ' LIMIT 0,5', function(err, rows) {
    //         if (err) {
    //             res.render('template/index', { title: 'Express', datas: [] }); // this renders "views/template/index.html"
    //         } else {
    //             res.render('template/index', { title: 'Express', datas: rows });
    //         }
    //         connection.release();
    //     });
    // });
    res.render('template/index', { title: 'Express', datas: [{ userid: '111', name: '1ddd', age: '1' }, { userid: '222', name: '2ddd', age: '2' }, { userid: '333', name: '3ddd', age: '33' }] });
});

module.exports = router;