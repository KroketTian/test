define(function(require, exports, module){
    var app = seajs.data.vars.app;
    var mod = seajs.data.vars.module;
    var pub = seajs.data.vars['public'];
    var base = seajs.data.base;

    var $ = require('jquery');
	require('vue');
	require('element');
    var common = require('common');
	$(function(){
		var app = new Vue({
			el: '#cloud',
			data: {
			  message: 'Hello Vue!',
			  visible: false,
			  select: "1",
			  tableData: [{
				date: '2016-05-03',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			  }, {
				date: '2016-05-02',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			  }, {
				date: '2016-05-04',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			  }, {
				date: '2016-05-01',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			  }, {
				date: '2016-05-08',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			  }, {
				date: '2016-05-06',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			  }, {
				date: '2016-05-07',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			  }]
			}
		})
	})
});
