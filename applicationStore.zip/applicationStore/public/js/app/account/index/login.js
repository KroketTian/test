define(function(require, exports, module){
    var app = seajs.data.vars.app;
    var mod = seajs.data.vars.module;
    var pub = seajs.data.vars['public'];
    var base = seajs.data.base;

    var $ = require('jquery');
	require('vue');
	require('element');
    var common = require('common');
	$(function(){
		var app = new Vue({
			el: '#app',
			data: {
			  message: 'Hello Vue!',
			  visible: false
			}
		})
	})
});
