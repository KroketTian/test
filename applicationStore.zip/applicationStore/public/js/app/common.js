define(function(require, exports, module){
    var app = seajs.data.vars.app;
    var mod = seajs.data.vars.module;
    var pub = seajs.data.vars['public'];
    var root = seajs.data.vars.root;
    var base = seajs.data.base;

    var $ = require('jquery');
    require('layer');
    layer.config({
        //path: '/res/layer/' //layer.js所在的目录，可以是绝对目录，也可以是相对目录
        path: require.resolve('layer').replace(/layer.js\?\d*/, ''),
        extend: ['skin/bsskin/style.css'], //加载新皮肤
        skin: 'layer-ext-bsskin' //一旦设定，所有弹层风格都采用此主题。
    });

    require('placeholder');

    /*
    function layerMsg(msg){
        layer.alert(msg, {
          icon: 1,
          skin: 'layer-ext-moon' //该皮肤由layer.seaning.com友情扩展。关于皮肤的扩展规则，去这里查阅
        });
    }
    */

    // 兼容IE8及以下
    String.prototype.repeat = String.prototype.repeat || function(n) { 
        var _this = this;
        var result = '';
        for(var i=0;i<n;i++) {
            result += _this;
        }
        return result;
    };

    /** * 对Date的扩展，将 Date 转化为指定格式的String * 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q)
        可以用 1-2 个占位符 * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) * eg: * (new
        Date()).pattern("yyyy-MM-dd hh:mm:ss.S")==> 2006-07-02 08:09:04.423      
     * (new Date()).pattern("yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04      
     * (new Date()).pattern("yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04      
     * (new Date()).pattern("yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04      
     * (new Date()).pattern("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18      
     */ 
    Date.prototype.pattern = function(fmt) {         
        var o = {         
        "M+" : this.getMonth()+1, //月份         
        "d+" : this.getDate(), //日         
        "h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时         
        "H+" : this.getHours(), //小时         
        "m+" : this.getMinutes(), //分         
        "s+" : this.getSeconds(), //秒         
        "q+" : Math.floor((this.getMonth()+3)/3), //季度         
        "S" : this.getMilliseconds() //毫秒         
        };         
        var week = {         
        "0" : "/u65e5",         
        "1" : "/u4e00",         
        "2" : "/u4e8c",         
        "3" : "/u4e09",         
        "4" : "/u56db",         
        "5" : "/u4e94",         
        "6" : "/u516d"        
        };         
        if(/(y+)/.test(fmt)){         
            fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));         
        }         
        if(/(E+)/.test(fmt)){         
            fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "/u661f/u671f" : "/u5468") : "")+week[this.getDay()+""]);         
        }         
        for(var k in o){         
            if(new RegExp("("+ k +")").test(fmt)){         
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));         
            }         
        }         
        return fmt;         
    }; 

    //日期输出字符串，重载了系统的toString方法  
    Date.prototype.toString = function(showWeek)  
    {   
        var myDate= this;  
        // var str = myDate.toLocaleDateString();  
        var str='';
        if (showWeek)  
        {   
            var Week = ['日','一','二','三','四','五','六'];  
            str += ' 星期' + Week[myDate.getDay()]+' ';  
        }  
        return str;  
    }; 


    // 货币格式化输出
    Number.prototype.formatMoney = function (places, symbol, thousand, decimal) {
        places = !isNaN(places = Math.abs(places)) ? places : 2;
        //symbol = symbol !== undefined ? symbol : "$";
        symbol = symbol !== undefined ? symbol : "";
        thousand = thousand || ",";
        decimal = decimal || ".";
        var number = this,
            negative = number < 0 ? "-" : "",
            i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + "",
            j = (j = i.length) > 3 ? j % 3 : 0;
        return symbol + negative + (j ? i.substr(0, j) + thousand : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : "");
    };


    // 根据对象属性值获取对象属性
    exports.getKeyByValue = function(obj, val){
        if(!obj){
            return null;
        }

        for(var k in obj){
            if(obj[k] == val){
                return k;
                break;
            }
        }

        return null;
    };


    // 获取URL请求参数
    exports.getQueryString = getQueryString = function(name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = window.location.search.substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    };

    // 判断是否为数组
    exports.isArray = function(obj){
        return Object.prototype.toString.call(obj) === '[object Array]';    
    };
    /*
    根据〖中华人民共和国国家标准 GB 11643-1999〗中有关公民身份号码的规定，公民身份号码是特征组合码，由十七位数字本体码和一位数字校验码组成。排列顺序从左至右依次为：六位数字地址码，八位数字出生日期码，三位数字顺序码和一位数字校验码。
        地址码表示编码对象常住户口所在县(市、旗、区)的行政区划代码。
        出生日期码表示编码对象出生的年、月、日，其中年份用四位数字表示，年、月、日之间不用分隔符。
        顺序码表示同一地址码所标识的区域范围内，对同年、月、日出生的人员编定的顺序号。顺序码的奇数分给男性，偶数分给女性。
        校验码是根据前面十七位数字码，按照ISO 7064:1983.MOD 11-2校验码计算出来的检验码。

    出生日期计算方法。
        15位的身份证编码首先把出生年扩展为4位，简单的就是增加一个19或18,这样就包含了所有1800-1999年出生的人;
        2000年后出生的肯定都是18位的了没有这个烦恼，至于1800年前出生的,那啥那时应该还没身份证号这个东东，⊙﹏⊙b汗...
    下面是正则表达式:
     出生日期1800-2099  (18|19|20)?\d{2}(0[1-9]|1[12])(0[1-9]|[12]\d|3[01])
     身份证正则表达式 /^\d{6}(18|19|20)?\d{2}(0[1-9]|1[12])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i            
     15位校验规则 6位地址编码+6位出生日期+3位顺序号
     18位校验规则 6位地址编码+8位出生日期+3位顺序号+1位校验位
     
     校验位规则     公式:∑(ai×Wi)(mod 11)……………………………………(1)
                    公式(1)中： 
                    i----表示号码字符从由至左包括校验码在内的位置序号； 
                    ai----表示第i位置上的号码字符值； 
                    Wi----示第i位置上的加权因子，其数值依据公式Wi=2^(n-1）(mod 11)计算得出。
                    i 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1
                    Wi 7 9 10 5 8 4 2 1 6 3 7 9 10 5 8 4 2 1

    */
    //身份证号合法性验证 
    //支持15位和18位身份证号
    //支持地址编码、出生日期、校验位验证
    exports.IdentityCodeValid = function(idCard) { 
        //15位和18位身份证号码的正则表达式
         var msg=false;
         var regIdCard=/^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;

         //如果通过该验证，说明身份证格式正确，但准确性还需计算
         if(regIdCard.test(idCard)){
          if(idCard.length==18){
           var idCardWi=new Array( 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ); //将前17位加权因子保存在数组里
           var idCardY=new Array( 1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2 ); //这是除以11后，可能产生的11位余数、验证码，也保存成数组
           var idCardWiSum=0; //用来保存前17位各自乖以加权因子后的总和
           for(var i=0;i<17;i++){
            idCardWiSum+=idCard.substring(i,i+1)*idCardWi[i];
           }

           var idCardMod=idCardWiSum%11;//计算出校验码所在数组的位置
           var idCardLast=idCard.substring(17);//得到最后一位身份证号码

           //如果等于2，则说明校验码是10，身份证号码最后一位应该是X
           if(idCardMod==2){
            if(idCardLast=="X"||idCardLast=="x"){
                msg=true;
            }else{
                msg=false;
            }
           }else{
            //用计算出的验证码与最后一位身份证号码匹配，如果一致，说明通过，否则是无效的身份证号码
            if(idCardLast==idCardY[idCardMod]){
                msg=true;
            }else{
                msg=false;
            }
           }
          } 
         }else{
             msg=false;
         }
         return msg;
    };

    exports.isEmail = function(strEmail) {
        if (strEmail.search(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) != -1)
            return true;
        else
            return false;
    };

    exports.isMobile = function(mobile){
        var reg = /^0?1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        if (reg.test(mobile)) {
            return true;
        }else{
            return false;
        }
    };

    exports.isPassWord = function(strPw) {
        var reg = /^[^\s\u4e00-\u9fa5]{6,32}$/g;
        return reg.test(strPw);
    }

    //判断是否属于IP地址
    exports.isIp = function(addr){
        var reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/;
        if(addr.match(reg)){
            return true;
        }else{
            return false;
        }
    };

    // 判断数字是否 正整数 或 0
    exports.isNotNegativeInt = function (num) {
        if (num == null) return false;
        else if (num == '0' ) return true;
        //else if (num == '0' || num == '0.5' || num == '1.5') return true;
        var reg = /^[0-9]*[1-9][0-9]*$/; //正整数      
        return reg.test(num);
    };

    // VM公共方法start
    // ============================================

    /*
        init: 初始化状态
        available: 是否可用
        ps: 电源状态
        lastopt: 上次操作 
        lastopttime: 上次操作时间 
        createtime: 创建时间 
        unixTime: 服务器时间戳
        isDelete: 欠费停机标识位, 0-正常, 1-数据库删除(前端不关心), 2-暂不可用, 3-欠费停机
    */
    exports.getStatus = function(init, available, ps, lastopt, lastopttime, createtime, unixTime, isDelete){
        // 统一初始时间单位为秒
        var optTimePeriod = unixTime - lastopttime;
        var lifePeriod = unixTime - createtime;
        var optMin = Math.floor(optTimePeriod / 60);
        var lifeMin = Math.floor(lifePeriod / 60);
        //console.log("init, available, ps, lastopt, lastopttime, createtime, unixTime");
        //console.log(init, available, ps, lastopt, lastopttime, createtime, unixTime);

        var ret = '状态失败';

        if(init == 0){
            ret = '创建中';
            return ret;
        }

        if(init >= 2){
            ret = '初始化失败';
            return ret;
        }


        //is_delete: 0-正常, 1-数据库删除(前端不关心), 2-暂不可用, 3-欠费停机
        // 欠费停机判断
        if(isDelete == 2){
            ret = '暂不可用';
            return ret;
        }else if(isDelete == 3){
            ret = '欠费停机';
            return ret;
        }

        if(!available && !ps ){
            ret = '状态同步中';
            return ret;
        }

        if(optMin < 15 && lastopt =='reinstall' && ps != 'Running'){
            ret = '重装中';
            return ret;
        }else if(available == 'False' && ((optMin >= 30 && lastopt =='reinstall')|| (lastopt == 'reinstalled'))){
            ret = '重装失败';
            return ret;
        }
        if(optMin <30 && lastopt == 'Copy'){
            ret = '复制中';
            return ret;
        }else if(optMin >= 30 && lastopt == 'Copy'){
            ret = '复制失败';
            return ret;
        }

        // init == 1
        if(available == 'False'){
            // 不可用，available == 'False'
            if(optMin < 30 && ( lastopt == 'init' || lastopt == 'Init' )){
                ret = '初始化中'
                return ret;
            }else{
                ret = '暂不可用';
                return ret;
            }
        }else if(optMin >= 10 || lastopt == 'sync'){
            // 可用并且操作时长>=10min  available == 'True' && optMin >= 10
            if(ps == 'Running'){
                ret = '运行中';
                return ret;
            }else if(ps == 'Paused'){
                ret = '暂停';
                return ret;
            }else if(ps == 'Halted'){
                ret = '已关机';
                return ret;
            }else if(ps == 'Suspended'){
                ret = '挂起';
                return ret;
            }
        }else{
            // 可用并且操作时长小于10min  available == 'True' && optMin < 10

            if( lastopt == 'Reboot' && (ps != 'Running' || optTimePeriod < 60) ){
                ret = '重启中';
                return ret;
            }

            if( lastopt == 'Run' && ps != 'Running'){
                ret = '开机中';
                return ret;
            }

            if( lastopt == 'Halt' && ps != 'Halted'){
                ret = '关机中';
                return ret;
            }

            if( (lastopt == 'Halt' || lastopt == 'Init' || lastopt=='init') && ps == 'Halted'){
                ret = '已关机';
                return ret;
            }

            if( (lastopt == 'Init' || lastopt == 'Run' || lastopt == 'Reboot' || lastopt=='init' || lastopt=='reinstall') && ps == 'Running'){
                ret = '运行中';
                return ret;
            }
        }

        return ret;
    };


    var diskDescMap = exports.diskDescMap = {
        'iSCSI_SATA': '中心存储',
        'iSCSI_SSD': 'SSD存储',
        'RBD_HDD': '中心存储',
        'RBD_SSD': 'SSD存储'
    };

    var bandDescMap = exports.bandDescMap = function(value, houseName){
        var map = {
            'VM_Y1IP':'香港国际',
            'VM_V1IP':'香港带宽',
            'VM_W1IP':'国际线路',
            'VM_X1IP':'香港带宽',
            'VM_U1IP':'广电单线',
            'VM_T1IP':'铁通单线',
            'VM_S1IP':'移动单线',
            'VM_Z1IP':'双线',
            'VM_P1IP':'三线带宽',
            'VM_O1IP':'三线带宽',
            'VM_N1IP':'三线带宽',
            'VM_M1IP':'三线带宽',    
            'VM_L1IP':'三线带宽',
            'VM_K1IP':'双线带宽',
            'VM_J1IP':'双线带宽',
            'VM_I1IP':'双线带宽',
            'VM_BGPIP': 'BGP带宽',
            'VM_SXIP-Ⅰ': '双线带宽-I',
            'VM_R1IP' : '联通单线',
            'VM_PRIIP':'内部网络',
            'VM_Q1IP' : '电信单线',
            'VM_A2IP' :'国际线路',
            'VM_B1IP': 'BGP',
            'VM_C1IP': 'BGP',
            'VM_D1IP': 'BGP'
        };

        if(houseName && houseName.indexOf('香港') != -1){
            if(value == 'VM_BGPIP'){
                return '香港带宽';
            }
        }

        return map[value];
    };

    var ipTypeDescMap = exports.ipTypeDescMap = {
        //'VM_PRIIP': '内部网络',
        
        // 'VM_Y1IP' : 'BGP',
        // 'VM_BGPIP': 'BGP',
        // 'VM_TCIP': '电信',
        // 'VM_UNIP': '联通',
        // 'VM_SXIP-Ⅰ': '双线',
        // 'VM_R1IP': '单联通',
        // 'VM_Q1IP' : '单电信'
        'VM_Y1IP':'香港国际',
        'VM_V1IP':'香港',
        'VM_W1IP':'国际',
        'VM_X1IP':'香港',
        'VM_U1IP':'单广电',
        'VM_T1IP':'单铁通',
        'VM_S1IP':'单移动',
        'VM_Z1IP':'双线',
        'VM_P1IP':'三线',
        'VM_O1IP':'三线',
        'VM_N1IP':'三线',
        'VM_M1IP':'三线',    
        'VM_L1IP':'三线',
        'VM_K1IP':'双线',
        'VM_J1IP':'双线',
        'VM_I1IP':'双线',
        'VM_BGPIP': 'BGP',
        'VM_TCIP': '电信',
        'VM_UNIP': '联通',
        'VM_PRIIP': '内网',
        'VM_SXIP-Ⅰ' : '双线',
        'VM_R1IP' : '单联通',
        'VM_Q1IP' : '单电信',
        'VM_A2IP' :'国际线路',
        'VM_B1IP': 'BGP',
        'VM_C1IP': 'BGP',
        'VM_D1IP': 'BGP',
        'undefined': ''
    };

    // 公网IP描述转json数组
    var publicIpStr2Arr = exports.publicIpStr2Arr = function(publicIpStr, ipType){
        try{
            var json = JSON.parse(publicIpStr);
        }catch(ex){
            return [{ip: publicIpStr, iptype: ipType}];
        }

        var ret = [];
        for(var k in json){
            if(json.hasOwnProperty(k)){
                ret.push({
                    ip: json[k],
                    iptype: k.indexOf('TCIP') != -1 ? 'VM_TCIP' : (k.indexOf('UNIP') != -1 ? 'VM_UNIP' : 'unknown')
                });
            }
        }

        return ret;
    }

    // 公网IP字符串转化，ip1，ip2
    var publicIpStr2 = exports.publicIpStr2 = function(publicIpStr, ipType){
        try{
            var json = JSON.parse(publicIpStr);
        }catch(ex){
            return [publicIpStr];
        }

        var ret = [];
        for(var k in json){
            if(json.hasOwnProperty(k)){
                ret.push(json[k]);
            }
        }

        return ret;
    }

    // ===== main ======
    if( typeof layer !== 'undefined' ){

        _layer = layer; // 保存本层layer
        layer = top.layer;// 全局化layer

        var layerMsg = exports.layerMsg = function(msg, options){
            var settings = {
                //skin: 'layer-ext-moon'
            };
            $.extend(settings, options);

            return layer.alert(msg, settings);
        };

        var layerSuccMsg = exports.layerSuccMsg = function(msg, options){
            var settings = {
                  icon: 1
            };
            $.extend(settings, options);

            return layerMsg(msg, settings);
        };

        var layerErrorMsg = exports.layerErrorMsg = function(msg, options){
            var settings = {
                  icon: 0
            };
            $.extend(settings, options);

            return layerMsg(msg, settings);
        };

        var layerErrorMsgTime = exports.layerErrorMsgTime = function(msg, options){
            var settings = {
                  icon: 2,
                  time: 2500
            };
            $.extend(settings, options);

            return layer.msg(msg, settings);
        };

        // 余额不足对话框，可跳转到充值页面
        exports.layerLackOfMoney = function(msg){
            return layer.confirm(msg, {
                icon: 0,
                btn: ['立即充值', '取消']
            }, function(index) {
                top.funcs.loadPage(mod + '/User/cost');
                layer.closeAll();
            });
        };

        var closeInside = exports.closeInside = function(){
            var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
            parent.layer.close(index); //再执行关闭
        }
    }

    var payType = exports.payType = function(type){
        switch(type){
            case '1' : return '支付宝';
            case '2' : return '微信支付';
            case '3' : return '网银';
            case '4' : return '现金充值';
            case '5' : return '代金券赠送'; //系统赠送
            case '6' : return '现金回收'; //现金充值
            case '7' : return '代金券回收'; //系统赠送
            default : return '';
        }
    }

    // 内存配置
    var ramConf = exports.ramConf = {
        '1':[1,2,4],
        '2':[2,4,8],
        '4':[4,8,16],
        '8':[8,16,32],
        '12':[12,24,48],
        '16':[16,32,64],
        '32':[64,128]
    }
    // cpu配置
    var cpuConf = exports.cpuConf = [1,2,4,8,12,16,32];

    exports.getCookie = function(name) {
        var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
        if (arr = document.cookie.match(reg)){
            return unescape(arr[2]);
        }else{
            return null; 
        }
    }

    exports.setCookie = function(c_name,value,time){
        var exdate=new Date()
        exdate.setTime(exdate.getTime()+time)
        document.cookie=c_name+ "=" +escape(value)+
        ((time==null) ? "" : ";expires="+exdate.toGMTString())+';path=/'+';domain='+window.location.host;
    }


    //===== 备案验证 =====
    //港澳回归证
    //通行证号码组成规则：通行证证件号码共11位。第1位为字母，“H”字头签发给香港居民，“M”字头签发给澳门居民；
    //第2位至第11位为数字，前8位数字为通行证持有人的终身号，后2位数字表示换证次数，首次发证为00，此后依次递增。 
    exports.isPassCheck = function(passCheck){
        var reg = /^[HM]{1}\d{8}$/;
        if (reg.test(passCheck)) {
            return true;
        }else{
            return false;
        }
    };

    //办公室电话号码
    //手机号码 或 区号-电话号码
    exports.isTele = function(mobile){
        //检验是否是手机号码
        var reg = /^0?1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        if (reg.test(mobile)) {
            return true;
        }

        reg = /^0\d{2,3}-?\d{7,8}$/;
        if (reg.test(mobile)) {
            return true;
        }else{
            return false;
        }
    };

    //判断域名
    exports.isURL = function(str_url){
        // var strRegex = "^((https|http|ftp|rtsp|mms)?://)"
        // + "?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?" //ftp的user@
        // + "(([0-9]{1,3}\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
        // + "|" // 允许IP和DOMAIN（域名）
        // + "([0-9a-z_!~*'()-]+\.)*" // 域名- www.
        // + "([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\." // 二级域名
        // + "[a-z]{2,6})" // first level domain- .com or .museum
        // + "(:[0-9]{1,4})?" // 端口- :80
        // + "((/?)|" // a slash isn't required if there is no file name
        // + "(/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+/?)$";
        // var reg = /((https|http|ftp|rtsp|mms):\/\/)?(([0-9a-z_!~*'().&=+$%-]+:)?[0-9a-z_!~*'().&=+$%-]+@)?(([0-9]{1,3}\.){3}[0-9]{1,3}|([0-9a-z_!~*'()-]+\.)*([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\.[a-z]{2,6})(:[0-9]{1,4})?((\/?)|(\/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+\/?)/g;
        // var reg=new RegExp(strRegex);
        var reg=/[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\.?/g;


        if(str_url.match(reg)){
            var domains=str_url.split(".");
            for(var i=0;i<domains.length;i++){
                if(domains[i]=="www"){
                    return false;
                }
            }

            return true;
        }else{
            return false;
        }
    };

    //网站网址
    exports.isIndex = function(index){
        var strRegex = "^((https|http|ftp|rtsp|mms)?://)"
        + "?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?" //ftp的user@
        + "(([0-9]{1,3}\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
        + "|" // 允许IP和DOMAIN（域名）
        + "([0-9a-z_!~*'()-]+\.)*" // 域名- www.
        + "([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\." // 二级域名
        + "[a-z]{2,6})" // first level domain- .com or .museum
        + "(:[0-9]{1,4})?" // 端口- :80
        + "((/?)|" // a slash isn't required if there is no file name
        + "(/[0-9a-zA-Z_!~*'().;?:@&=+$,%#-]+)+/?)$";
        // var reg = /((https|http|ftp|rtsp|mms):\/\/)?(([0-9a-z_!~*'().&=+$%-]+:)?[0-9a-z_!~*'().&=+$%-]+@)?(([0-9]{1,3}\.){3}[0-9]{1,3}|([0-9a-z_!~*'()-]+\.)*([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\.[a-z]{2,6})(:[0-9]{1,4})?((\/?)|(\/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+\/?)/g;
        var reg=new RegExp(strRegex);

        if(index.match(reg)){
            return true;
        }else{
            return false;
        }
    };

    //检验输入是否为空或者全部是空格
    exports.isNullOrBlank = function(str){
        if ( str == "" ){
            return true;
        } 

        var reg = /^[ ]+$/;
        // var reg = new RegExp(express);
        if(reg.test(str)){
            return true;
        }else{
            return false;
        }
    };

    exports.systemIcon = function(systemName){
        var name = systemName;

        if (name.indexOf('CentOS') != -1) {
            return '/img/sysicon/a1.jpg';
        } else if (name.indexOf('Ubuntu') != -1) {
            return '/img/sysicon/a2.jpg';
        } else if (name.indexOf('RHEL') != -1 || name.indexOf('RedHat') != -1) {
            return '/img/sysicon/a3.jpg';
        } else if (name.indexOf('SLES') != -1 || name.indexOf('openSUSE') != -1) {
            return '/img/sysicon/a4.jpg';
        } else if (name.indexOf('Debian') != -1) {
            return '/img/sysicon/a5.jpg';
        } else if (name.indexOf('Gentoo') != -1) {
            return '/img/sysicon/a6.jpg';
        } else if (name.indexOf('Windows') != -1) {
            return '/img/sysicon/a7.jpg';
        } else if (name.indexOf('Fedora') != -1) {
            return '/img/sysicon/a8.png';
        }
        return '';
    }

    exports.deal_house = function(house){
        var obj = [];
        for (var i = 0; i < house.length; i++) {
            if(house[i].GroupType === 'class'){ // 去除vpc节点
                var housename = house[i].StockHouseName;
                var index = /[a-zA-Z]/g.exec(housename);
                if(index){
                    housearea = housename.slice(0, index.index);
                    if(!housearea){
                        housearea = housename;
                    }
                    if(!has_housearea(housearea,obj)){
                        var arr = [];
                        var sort = 0;
                        for (var j = 0; j < house.length; j++) {
                            var housename_obj = house[j].StockHouseName;
                            if(housename_obj.indexOf(housearea) > -1 && house[j].GroupType === 'class'){
                                arr.push(house[j]);
                                house[j].sort = house[j].sort ? parseInt(house[j].sort) : 0;
                                sort = house[j].sort > sort ? house[j].sort : sort;
                            }
                        }
                        obj.push({
                            'name' : housearea,
                            'house' : arr,
                            'sort': sort
                        });
                    }
                }else{
                    obj.push({
                        'name' : housename,
                        'house' : [house[i]],
                        'sort': house[i].sort ?  parseInt(house[i].sort) : 0
                    });
                }
            }
        }
        return nodeSort(obj);
    }

    function has_housearea(name,list){
        for(var i =0 ; i < list.length;i++){
            if(name == list[i].name){
                return true;
            }
        }

        return false;
    }
    function nodeSort(obj) {
        for (var one of obj) {
            one['house'] = chineseSort(one.house, 'StockHouseName');
        }

        return chineseSort(obj, 'name');
    }

    // 中文排序
    function chineseSort(arr, name) {
        var newArr = [];
        newArr = arr.sort(function(a, b) {
            return  a.sort < b.sort ? 1 : ( a.sort === b.sort ? a[name].localeCompare(b[name], 'zh') : -1);
        });
        return newArr;
    }
    
    //获取 年月日 时
    function ymdh(time){
            var date = new Date(time);
            var Y = date.getFullYear() + '-';
            var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
            var D = date.getDate() < 10 ? '0' + date.getDate()+ ' ' : date.getDate()+ ' ';
            var h = date.getHours() < 10 ? ' 0' + date.getHours() + ':' : +' ' + date.getHours() + ':' ;
            return Y+M+D+h
     }
     // 获取 年月日 时分秒
     function allTime(time){
            var date = new Date(time);
            var middleValue = ymdh(time);
            var m = date.getMinutes() < 10 ? '0' + date.getMinutes() + ':' : date.getMinutes() +':';
            var s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
            return middleValue+m+s;
     }
    // 整点、半点. time为时间戳 秒
    exports.timestampToTime = function(time) {
        var date = new Date(time * 1000);
        var m = date.getMinutes() ;
        var s = date.getSeconds() ;
        var middleValue = '';
        if((m == 0 && s == 0) || (m==30 && s==0) ){
            return allTime(date);
        }
        if(m < 30 ){
            m = 30;
            s = ':00';
            middleValue = ymdh(date);
            return middleValue+m+s;
        }else if(m > 30 || m==30){
            return allTime((Number(time) + (59 - m)*60 + (60 - s))*1000);
        }
    }

    var money_ajax;
    exports.flushMoney=function() {
        if (money_ajax != null) {
            money_ajax.abort();
        }

        money_ajax= $.ajax({
            url: app + '/Api/System/getHomePageInfo',
            timeout: 5000,
            dataType: 'json',
            async:false
        }).done(function(data) {
            if (data.ret > 0) {
                common.layerErrorMsg(data.msg);
                return;
            }

            top.GLOBAL.total = data.data.totalmoney;
            top.money_dom.text(top.GLOBAL.total);
        });
    }

    exports.getManagerCode = function(){
        if(getQueryString('manager')){
            localStorage.setItem('manager_code',getQueryString('manager'));
        }
    }

    // 判断地址：不能为空，不能为纯空格字符，不能为纯数字
    exports.isAddress = function(str) {
        var regNumAll=/^[0-9]*$/;
        var newStr=!str?str:str.replace(/\s+/g, "");
        return !!newStr&&!regNumAll.test(newStr);
    }

    // 行业类型转换
    exports.companyType = function(value) {
        var map = {
            '1': '限时通信',
            '2': '搜索引擎',
            '3': '综合门户',
            '4': '网上邮局',
            '5': '网络新闻',
            '6': '博客/个人空间',
            '7': '网络广告信息',
            '8': '单位门户网站',
            '9': '网络购物',
            '10': '网上支付',
            '11': '网上银行',
            '12': '网上炒股/股票基金',
            '13': '网络游戏',
            '14': '网络音乐',
            '15': '网上影视',
            '16': '网上图片',
            '17': '网络软件下载',
            '18': '网上求职',
            '19': '网上交友婚介',
            '20': '网上房产',
            '21': '网络教育',
            '22': '网站建设',
            '23': 'WAP',
            '24': '其它'
        }

        if(!map[value]){
            return '';
        }
        return map[value];
    }
    
    exports.companyTypeToNum = function(value) {
        var map = {
            '限时通信': '1',
            '搜索引擎': '2',
            '综合门户': '3',
            '网上邮局': '4',
            '网络新闻': '5',
       '博客/个人空间': '6',
        '网络广告信息': '7',
        '单位门户网站': '8',
            '网络购物': '9',
            '网上支付': '10',
            '网上银行': '11',
    '网上炒股/股票基金': '12',
            '网络游戏': '13',
            '网络音乐': '14',
            '网上影视': '15',
            '网上图片': '16',
        '网络软件下载': '17',
            '网上求职': '18',
        '网上交友婚介': '19',
            '网上房产': '20',
            '网络教育': '21',
            '网站建设': '22',
                'WAP': '23',
               '其它': '24'
        }

        if(!map[value]){
            return '';
        }

        return map[value];
    }
});
