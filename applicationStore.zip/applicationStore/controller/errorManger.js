const fs = require('fs');
class ErrorManager {
}

module.exports = ErrorManager;